/**
 * \file ActorFactory.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include "ActorFactory.h"

/** Constructor */
CActorFactory::CActorFactory()
{
}


/** Destructor */
CActorFactory::~CActorFactory()
{
}
