/**
 * \file AirSinkDestination.cpp
 *
 * \author Andrew Haakenson
 */

#include "pch.h"
#include "AirSinkDestination.h"
