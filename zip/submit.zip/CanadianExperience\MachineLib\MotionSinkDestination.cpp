/**
 * \file MotionSinkDestination.cpp
 *
 * \author Andrew Haakenson
 */

#include "pch.h"
#include "MotionSinkDestination.h"
