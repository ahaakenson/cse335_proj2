/**
 * \file PictureFactory.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include "PictureFactory.h"
#include "HaroldFactory.h"
#include "SpartyFactory.h"
#include "ImageDrawable.h"
#include "MachineAdapter.h"

using namespace std;
using namespace Gdiplus;

/**
 * Constructor
*/
CPictureFactory::CPictureFactory()
{
}

/**
 * Destructor
*/
CPictureFactory::~CPictureFactory()
{
}


/** Factory method to create a new picture.
* \returns The created picture
*/
std::shared_ptr<CPicture> CPictureFactory::Create()
{
    shared_ptr<CPicture> picture = make_shared<CPicture>();

    // Create the background and add it
    auto background = make_shared<CActor>(L"Background");
    background->SetClickable(false);
    background->SetPosition(Point(-100, 0));
    auto backgroundI = make_shared<CImageDrawable>(L"Background", L"images/Background.png");
    background->AddDrawable(backgroundI);
    background->SetRoot(backgroundI);
    picture->AddActor(background);

    // Create machine 1
    auto machineActor = make_shared<CActor>(L"Machine Actor");
    auto machine = make_shared<CMachineAdapter>(L"Machine 1");
    machineActor->AddDrawable(machine);
    machine->Place(Point(200, 400), 0);

    // Create machine 2
    machine = make_shared<CMachineAdapter>(L"Machine 2");
    machineActor->AddDrawable(machine);
    machine->Place(Point(800, 400), 0);
    machine->SetMachineNumber(2);
    machine->SetStartFrame(600);

    picture->AddActor(machineActor);

    // Create and add Harold
    CHaroldFactory factory;
    auto harold = factory.Create();

    // This is where Harold will start out.
    harold->SetPosition(Point(750, 500));

    picture->AddActor(harold);

    // Create and add Sparty
    CSpartyFactory sfactory;
    auto sparty = sfactory.Create();

    sparty->SetPosition(Point(520, 500));
    picture->AddActor(sparty);

    return picture;
}
